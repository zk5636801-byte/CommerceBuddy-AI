# CommerceBuddy phone deployment guide

This package is adjusted to bind the web server to `0.0.0.0` for a hosting service. The local Windows `.bat` launchers remain included.

## Important before publishing
- Online AI requires an Anthropic API key and may incur usage charges. Never put the key in frontend files, commit it to GitHub, or share it in chat.
- This demo's API is not protected by user login. Anyone who obtains its public URL may be able to use its AI endpoint and consume your API quota. For a public exhibition, add authentication/access controls and usage limits before sharing the URL widely. Do not add payment details unless a parent/guardian approves and understands the charges.
- Microphone input depends on the browser's speech recognition support and microphone permission. Speech output uses browser voices.

## Deploy outline (requires an account)
1. Create a private GitHub repository and upload the contents of the `CommerceBuddy` folder (not the parent folder). Do not upload `.env` or any API key.
2. In Render, create a new Web Service from that repository. Render should detect `render.yaml`; if not, set runtime Python, build command `python --version`, start command `python backend/app.py`.
3. In the service's Environment settings, add `ANTHROPIC_API_KEY` as a secret environment variable. Never place it in code or the repository. If you do not set it, the app runs in offline-demo mode.
4. Deploy and open the service's HTTPS URL on your phone in Chrome.
5. Test text questions first, then allow microphone permission and test voice. Check service logs if anything fails.

## Local use on Windows
Run `START_OFFLINE_DEMO.bat` for offline mode or `START_COMMERCEBUDDY.bat` for local online AI after setting the key in `.env`.
